### What operating system are you using and which version ?

*Insert answer here*

### What Ruby version are you using ( `ruby -v` ) ?

*Insert answer here*

### Is your GEM environment properly configured and updated (  `sudo gem update` ) ?

*Insert answer here*

### Which version of BetterCap are you using (  `bettercap -v` ) ?

*Insert answer here*

### What's the output of BetterCap while the issue happens?

*Insert answer here*
